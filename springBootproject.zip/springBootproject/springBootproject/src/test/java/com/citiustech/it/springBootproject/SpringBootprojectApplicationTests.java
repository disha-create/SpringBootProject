package com.citiustech.it.springBootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
