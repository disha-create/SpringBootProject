package com.citiustech.it.springBootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootprojectApplication.class, args);
	}

}
