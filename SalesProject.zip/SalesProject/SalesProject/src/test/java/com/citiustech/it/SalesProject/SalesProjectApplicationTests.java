package com.citiustech.it.SalesProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
