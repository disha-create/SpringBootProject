package com.citiustech.it.SalesProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesProjectApplication.class, args);
	}

}
