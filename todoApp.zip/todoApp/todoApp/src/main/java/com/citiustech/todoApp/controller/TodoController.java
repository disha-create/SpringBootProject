package com.citiustech.todoApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.todoApp.DAO.TodoDao;
import com.citiustech.todoApp.model.Todo;

@RestController
@RequestMapping("todo")
public class TodoController {
	
	@Autowired
	private TodoDao todoDao;
	
	@GetMapping
	public String getData(){
		return "hello";
	}
	
	@PostMapping(value="save", consumes="application/json")
	public void saveTodo(@RequestBody Todo todo){
		todoDao.saveTodo(todo);
	}
	
	@PostMapping(value="update/{id}", consumes="application/json")
	public void updateTodo(@PathVariable int id, @RequestBody Todo todo){
		todoDao.updateTodo(todo);
	}
}
