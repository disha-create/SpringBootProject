package com.AOP.aopconcept.service;

public interface PaymentService {
	
	public void makePayment(int amaount);
}
