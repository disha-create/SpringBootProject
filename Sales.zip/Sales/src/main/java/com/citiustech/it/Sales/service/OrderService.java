package com.citiustech.it.Sales.service;

import java.time.LocalDate;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.Sales.model.Counter;
import com.citiustech.it.Sales.model.Customer;
import com.citiustech.it.Sales.model.Order;
import com.citiustech.it.Sales.model.Product;
import com.citiustech.it.Sales.repository.CounterRepository;
import com.citiustech.it.Sales.repository.CustomerRepository;
import com.citiustech.it.Sales.repository.OrderRepository;
import com.citiustech.it.Sales.repository.ProductRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private CounterService counterService;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private ProductRepository productRepository;

	public Collection<Order> getOrderByCustomerId(String id){
		Customer customer = new Customer();
		customer.setCustid(id);
		return orderRepository.findByCustomer(customer);
	}
	
	public Order getOrderById(int id){
		return orderRepository.findById(id);
	}
	
	public Order placeOrder(Order order){
		Counter counter = counterService.getOrderCounter();
		Product product = productRepository.getById(order.getProduct().getPno());
		
		if(product.getStock() > order.getQuantity()){
			Customer customer = customerRepository.findByCustomerId((order.getCustomer().getCustid()));
			if(customer.getCredit() > order.getQuantity() * product.getPrice()){
				
				order.setId(counterService.getNextValueofOrders(counter));
				order.setDate(LocalDate.now());
				order.setCustomer(customer);
				order.setProduct(product);
				orderRepository.save(order);
				
				product.setStock(product.getStock() - order.getQuantity());
				productRepository.save(product);
				
				customer.setCredit(customer.getCredit() - order.getQuantity() * product.getPrice());
				customerRepository.save(customer);
				
				counterService.incrementCounter(counter);
				
			}
			else{
				System.out.println("Insufficient Balance in Customer Credit");
			}
			
			
		}
		else{
			System.out.println("Less Stock");
		}
		
		return order;
	}
	
}
