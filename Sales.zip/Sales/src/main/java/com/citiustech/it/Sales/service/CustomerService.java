package com.citiustech.it.Sales.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.Sales.exceptionHandling.CustomerNotFoundException;
import com.citiustech.it.Sales.exceptionHandling.LoginFailedException;
import com.citiustech.it.Sales.model.Customer;
import com.citiustech.it.Sales.repository.CustomerRepository;


@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public void Login(Customer userCustomer) throws CustomerNotFoundException, LoginFailedException{
		
		Customer customer = customerRepository.findByCustomerId(userCustomer.getCustid());
		if(customer != null){
			if(customer.getPwd().compareTo(userCustomer.getPwd())==0){
				
			}
			else{
				throw new LoginFailedException("The username or password is incorrect..!");
			}
		}
		else{
			throw new CustomerNotFoundException("Customer not found with id:- " + userCustomer.getCustid());
		}
		
	}
}
