package com.citiustech.it.Sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.it.Sales.model.Counter;

@Repository
public interface CounterRepository extends JpaRepository<Counter,Integer> {

	
	Counter findByName(String name);
}
