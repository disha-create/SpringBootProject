package com.citiustech.it.Sales.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.it.Sales.model.Customer;
import com.citiustech.it.Sales.model.Order;


@Repository
public interface OrderRepository extends JpaRepository<Order, Integer>{
	
	Collection<Order> findByCustomer(Customer customer);
	
	Order findById(int id);

}
