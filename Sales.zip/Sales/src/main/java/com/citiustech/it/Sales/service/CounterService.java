package com.citiustech.it.Sales.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.Sales.model.Counter;
import com.citiustech.it.Sales.repository.CounterRepository;

@Service
public class CounterService {
	
	
	@Autowired
	private CounterRepository counterRepository;
	
	public Counter getCounter(String name){
		Counter counter = counterRepository.findByName(name);
		return counter;
	}
	
	public Counter getOrderCounter(){
		Counter counter = counterRepository.findByName("orders");
		return counter;
	}
	
	public Counter getProductCounter(){
		Counter counter = counterRepository.findByName("products");
		return counter;
	}

	public int getNextValueofOrders(Counter counter){
		return counter.getVal() + 1001;
	}
	
	public int getNextValueofProducts(Counter counter){
		return counter.getVal() + 301;
	}
	
	public void incrementCounter(Counter counter){
		counter.setVal(counter.getVal()+1);
		counterRepository.save(counter);
	}
	
}
