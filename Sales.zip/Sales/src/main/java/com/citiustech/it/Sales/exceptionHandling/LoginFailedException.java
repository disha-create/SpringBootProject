package com.citiustech.it.Sales.exceptionHandling;

public class LoginFailedException extends Exception {

	public LoginFailedException(String message){
		super(message);
	}
	
}
