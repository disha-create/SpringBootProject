package com.citiustech.it.Sales.repository;


import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citiustech.it.Sales.model.Invoice; 
@Repository
public class InvoiceDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Collection<Invoice> getAllInvoice(){
		return jdbcTemplate.query("select ord_no, ord_date, cust_id, pno, qty, amt from invoices", 
				new BeanPropertyRowMapper<Invoice>(Invoice.class));
	}
	
	public Collection<Invoice> getInvoiceByCustomer(String id){
		return jdbcTemplate.query("select ord_no, ord_date, cust_id, pno, qty, amt from invoices where cust_id=?", 
				new BeanPropertyRowMapper<Invoice>(Invoice.class));
	}
	
	public Collection<Invoice> getInvoiceById(String id){
		return jdbcTemplate.query("select ord_no, ord_date, cust_id, pno, qty, amt from invoices", 
				new BeanPropertyRowMapper<Invoice>(Invoice.class),id);
	}
	
	
}
