package com.citiustech.it.Sales.service;


import java.util.Collection;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.Sales.model.Counter;
import com.citiustech.it.Sales.model.Product;
import com.citiustech.it.Sales.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	
	@Autowired
	private CounterService counterService;
	
	public Collection<Product> getAllProducts(){
		return productRepository.findAll();
	}
	
	
	public Product getProduct(int id){
		return productRepository.findByPno(id);
	}
	

	public Product saveProduct(Product product){
		Counter counter = counterService.getProductCounter();
		product.setPno(counterService.getNextValueofProducts(counter));
		productRepository.save(product);
		counterService.incrementCounter(counter);
		return product;
	}

	public Product updateProduct(Product product){
		productRepository.save(product);
		return product;
	}
	
	public boolean checkProductById(int id){
		Product product = productRepository.findByPno(id);
		if(product != null){
			return true;
		}
		return false;
	}
}
