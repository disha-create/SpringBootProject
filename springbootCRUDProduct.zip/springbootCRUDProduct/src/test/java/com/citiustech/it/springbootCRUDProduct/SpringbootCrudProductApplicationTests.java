package com.citiustech.it.springbootCRUDProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
