package com.citiustech.it.springbootCRUDProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudProductApplication.class, args);
	}

}
