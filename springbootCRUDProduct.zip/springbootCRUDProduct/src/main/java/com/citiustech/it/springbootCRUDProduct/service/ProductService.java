package com.citiustech.it.springbootCRUDProduct.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.springbootCRUDProduct.model.Product;
import com.citiustech.it.springbootCRUDProduct.repository.ProductRepo;


@Service
public class ProductService {
	
	@Autowired
	private ProductRepo productRepo;
	
	
	public void saveProduct(Product product){
		productRepo.save(product);
	}

	public Collection<Product> getAllProducts(){
		System.out.println(productRepo.getClass());
		return (Collection<Product>) productRepo.findAll();
		
	}
	
}
