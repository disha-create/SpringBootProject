package com.citiustech.it.springbootCRUDProduct.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	private int pno;
	private double price;
	private int stock;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int pno, double price, int stock) {
		super();
		this.pno = pno;
		this.price = price;
		this.stock = stock;
	}
	
	@Id
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "Product [pno=" + pno + ", price=" + price + ", stock=" + stock + "]";
	}
	
	
	
}
