package com.citiustech.it.springbootCRUDProduct.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citiustech.it.springbootCRUDProduct.model.Product;
import com.citiustech.it.springbootCRUDProduct.service.ProductService;


@Controller
@RequestMapping("/")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping
	public void welcome(){
		System.out.println("Welcome!");
	}
	
	/*@GetMapping(value="all",produces="application/json")
	public Collection<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@PostMapping(value="save", consumes="application/json")
	public void saveProducr(@RequestBody Product product){
		productService.saveProduct(product);
	}*/
	
	
}
