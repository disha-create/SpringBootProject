package com.citiustech.it.springbootCRUDProduct.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.it.springbootCRUDProduct.model.Product;

@Repository
public interface ProductRepo extends CrudRepository<Product, Integer>{

}
