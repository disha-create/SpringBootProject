package com.example.it.SpringBootSales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
