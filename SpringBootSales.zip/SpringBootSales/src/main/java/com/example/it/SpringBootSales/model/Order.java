package com.example.it.SpringBootSales.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	
	private int id;
	private LocalDate date;
	private int quantity;
	
	@Id
	@Column(name="ord_no")
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	@Column(name="ord_date")
	public LocalDate getDate() {
		return date;
	}
	
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	@Column(name="qty")
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}	
	
	private Customer customer;

	@ManyToOne(targetEntity=Customer.class,cascade ={CascadeType.ALL})
	@JoinColumn(name="cust_id")
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	private Product product;

	@ManyToOne(targetEntity=Product.class)
	@JoinColumn(name="pno")
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", date=" + date + ", quantity=" + quantity + ", customer=" + customer + ", product="
				+ product + "]";
	}
	
	
	
	
	
	
}
