package com.example.it.SpringBootSales.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="counters")
public class Counter {

	private String name;
	private int val;
	
	@Id
	@Column(length=8,name="ctr_name")
	public String getName() {
		return name;
	}
	
	public void setName(String ctr_name) {
		this.name = ctr_name;
	}
	
	@Column(nullable=true,name="cur_val")
	public int getVal() {
		return val;
	}
	
	public void setVal(int cur_val) {
		this.val = cur_val;
	}

	@Override
	public String toString() {
		return "Counter [ctr_name=" + name + ", cur_val=" + val + "]";
	}
	
}
