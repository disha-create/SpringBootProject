package com.example.it.SpringBootSales.Service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.it.SpringBootSales.Dao.InvoiceDao;
import com.example.it.SpringBootSales.model.Invoice;


@Service
public class InvoiceService {

	@Autowired
	private InvoiceDao invoiceDao;
	
	public Collection<Invoice> getAllInvoices(){
		return invoiceDao.getAllInvoice();
	}
	
	public Collection<Invoice> getInvoiceByCustomer(String id){
		return invoiceDao.getInvoiceByCustomer(id);
	}
	
	public Collection<Invoice> getInvoiceByOrder(String id){
		return invoiceDao.getInoiceById(id);
	}
}
