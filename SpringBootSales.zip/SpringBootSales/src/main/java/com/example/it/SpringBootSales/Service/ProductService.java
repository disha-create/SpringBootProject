package com.example.it.SpringBootSales.Service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.it.SpringBootSales.Dao.ProductRepository;
import com.example.it.SpringBootSales.model.Counter;
import com.example.it.SpringBootSales.model.Product;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CounterService counterService;
	
	public Collection<Product> getAllProducts(){
		return productRepository.findAll();
	}
	
	public Product getProduct(int id){
		return productRepository.findByPno(id);
	}
	
	public Product saveProduct(Product product){
		Counter counter = counterService.getProductCounter();
		product.setPno(counterService.getNextValueofProducts(counter));
		productRepository.save(product);
		counterService.incrementCounter(counter);
		return product;
	}
	
	public Product updateProduct(Product product){
		productRepository.save(product);
		return product;
	}
	
	public boolean checkProductById(int id){
		Product product = productRepository.findByPno(id);
		if(product != null){
			return true;
		}
		return false;
	}
}
