package com.example.it.SpringBootSales.model;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	
	private String custid;
	private String pwd;
	private String email;
	private double credit;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(length=8,name="cust_id")
	public String getCustid() {
		return custid;
	}

	public void setCustid(String cust_id) {
		this.custid = cust_id;
	}

	@Column(length=16,nullable=true)
	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	@Column(length=32,nullable=true)
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public double getCredit() {
		return credit;
	}
	
	public void setCredit(double credit) {
		this.credit = credit;
	}

	@Override
	public String toString() {
		return "Customer [cust_id=" + custid + ", pwd=" + pwd + ", email=" + email + ", credit=" + credit + "]";
	}	
	
}
