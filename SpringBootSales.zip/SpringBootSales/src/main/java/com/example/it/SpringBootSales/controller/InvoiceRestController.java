package com.example.it.SpringBootSales.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.it.SpringBootSales.Service.InvoiceService;
import com.example.it.SpringBootSales.model.Invoice;

@RestController
@EnableWebMvc
@RequestMapping("/invoice")
public class InvoiceRestController {

	@Autowired
	private InvoiceService invoiceService;
	
	@GetMapping(produces="application/json")
	public Collection<Invoice> getAllInvoices(){
		return invoiceService.getAllInvoices();
	}
	
	@GetMapping(value="customer/{id}",produces="application/json")
	public Collection<Invoice> getInvoiceByCustomer(@PathVariable String id){
		return invoiceService.getInvoiceByCustomer(id);
	}
	
	@GetMapping(value="{id}",produces="application/json")
	public Collection<Invoice> getInvoiceByOrderId(@PathVariable String id){
		return invoiceService.getInvoiceByOrder(id);
	}
}
