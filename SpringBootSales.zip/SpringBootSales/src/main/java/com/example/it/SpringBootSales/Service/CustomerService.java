package com.example.it.SpringBootSales.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.it.SpringBootSales.Dao.CustomerRepository;
import com.example.it.SpringBootSales.model.Customer;
import com.example.it.SpringBootSales.Exception.CustomerNotFoundException;
import com.example.it.SpringBootSales.Exception.LoginFailedException;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	
	public void Login(Customer userCustomer) throws CustomerNotFoundException, LoginFailedException{
		Customer customer = customerRepository.findByCustid(userCustomer.getCustid());
		if(customer != null){
			if(customer.getPwd().compareTo(userCustomer.getPwd()) == 0){
				
			}else{
				throw new LoginFailedException("The username or password is incorrect..!");
			}
		}else{
			throw new CustomerNotFoundException("Customer not found with id:- " + userCustomer.getCustid());
		}
	}

}
