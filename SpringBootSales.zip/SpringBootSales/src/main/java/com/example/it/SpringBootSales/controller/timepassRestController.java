package com.example.it.SpringBootSales.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.it.SpringBootSales.Dao.CounterRepository;
import com.example.it.SpringBootSales.Dao.CustomerRepository;
import com.example.it.SpringBootSales.Dao.OrderRepository;
import com.example.it.SpringBootSales.Dao.ProductRepository;
import com.example.it.SpringBootSales.model.Counter;
import com.example.it.SpringBootSales.model.Customer;
import com.example.it.SpringBootSales.model.Order;
import com.example.it.SpringBootSales.model.Product;

@RestController
@EnableWebMvc
@RequestMapping("/hello")
public class timepassRestController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CounterRepository counterRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	
	@GetMapping(value="all", produces="application/json")
	public Collection<Customer> getAllTheEmplloyees(){
		return customerRepository.findAll();
	}
	
	@GetMapping
	public String hello(){
		return "Hello";
	}
	
	@GetMapping(value="counter",produces="application/json")
	public Collection<Counter> getAllCounter(){
		return counterRepository.findAll();
	}
	
	@GetMapping(value="counter/name",produces="application/json")
	public Counter getCounter(){
		return counterRepository.findByName("orders");
	}
	
	@GetMapping(value="product",produces="application/json")
	public Collection<Product> getAllProduct(){
		return productRepository.findAll();
	}
	
	@GetMapping(value="order",produces="application/json")
	public Collection<Order> getAllOrder(){
		return orderRepository.findAll();
	}
}
