package com.example.it.SpringBootSales.Service;

import java.time.LocalDate;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.it.SpringBootSales.Dao.CustomerRepository;
import com.example.it.SpringBootSales.Dao.OrderRepository;
import com.example.it.SpringBootSales.Dao.ProductRepository;
import com.example.it.SpringBootSales.model.Counter;
import com.example.it.SpringBootSales.model.Customer;
import com.example.it.SpringBootSales.model.Order;
import com.example.it.SpringBootSales.model.Product;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private CounterService counterService;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	
	public Collection<Order> getAllOrders(){
		return orderRepository.findAll();
	}
	
	public Collection<Order> getOrderByCustomerId(String id){
		Customer customer = new Customer();
		customer.setCustid(id);
		return orderRepository.findByCustomer(customer);
	}
	
	public Order getOrderById(int id){
		return orderRepository.findById(id);
	}
	
	public Order placeOrder(Order order){
		Counter counter = counterService.getOrderCounter();
		Product product = productRepository.getById(order.getProduct().getPno());
		if(product.getStock() > order.getQuantity()){
			Customer customer = customerRepository.findByCustid(order.getCustomer().getCustid());
			if(customer.getCredit() > order.getQuantity() * product.getPrice()){
				//Filling Order Details & add to Database
				order.setId(counterService.getNextValueofOrders(counter));
				order.setDate(LocalDate.now());
				order.setCustomer(customer);
				order.setProduct(product);
				orderRepository.save(order);
				
				//Product change Stock
				product.setStock(product.getStock() - order.getQuantity());
				productRepository.save(product);
				
				//Customer change Balance
				customer.setCredit(customer.getCredit() - order.getQuantity() * product.getPrice());
				customerRepository.save(customer);
				
				//Increment Counter
				counterService.incrementCounter(counter);
			}else{
				//Insufficient Balance in customer Credit
				System.out.println("Insufficient Balance in Customer Credit");
			}
		}else{
			//Exception for less Stock
			System.out.println("Less Stock");
		}
		
		return order;
		
	}
}
