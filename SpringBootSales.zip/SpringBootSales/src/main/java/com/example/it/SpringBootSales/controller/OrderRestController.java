package com.example.it.SpringBootSales.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.it.SpringBootSales.Service.OrderService;
import com.example.it.SpringBootSales.model.Order;

@RestController
@EnableWebMvc
@RequestMapping("/order")
public class OrderRestController {
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping(produces="application/json")
	public Collection<Order> getAllOrders(){
		return orderService.getAllOrders();
	}
	
	@GetMapping(value="customer/{id}",produces="application/json")
	public Collection<Order> getOrderByCustomerId(@PathVariable String id){
		return orderService.getOrderByCustomerId(id);
	}
	
	@GetMapping(value="{id}",produces="application/json")
	public Order getOrderById(@PathVariable int id){
		return orderService.getOrderById(id);
	}
	
	@PostMapping(produces="application/json",consumes="application/json")
	public Order saveOrder(@RequestBody Order order){
		return orderService.placeOrder(order);
	}
}
