package com.example.it.SpringBootSales.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.it.SpringBootSales.Service.CustomerService;
import com.example.it.SpringBootSales.model.Customer;
import com.example.it.SpringBootSales.Exception.CustomerNotFoundException;
import com.example.it.SpringBootSales.Exception.LoginFailedException;

@RestController
@EnableWebMvc
@RequestMapping("/auth")
public class AuthRestController {
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping(value="login",consumes="application/json")
	private ResponseEntity<?> login(@RequestBody Customer c) throws CustomerNotFoundException, LoginFailedException{
		customerService.Login(c);
		Map<String, String> info = new HashMap<>();
		info.put("CustomerId", c.getCustid());
		return new ResponseEntity<>(info , HttpStatus.OK);
	}
}
