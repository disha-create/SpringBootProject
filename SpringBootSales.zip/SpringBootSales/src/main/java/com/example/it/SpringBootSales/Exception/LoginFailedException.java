package com.example.it.SpringBootSales.Exception;

public class LoginFailedException extends Exception {

	public LoginFailedException(String message){
		super(message);
	}
}
