package com.example.it.SpringBootSales.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.it.SpringBootSales.model.Counter;

@Repository
public interface CounterRepository extends JpaRepository<Counter,Integer> {

	Counter findByName(String name);
}
