package com.example.it.SpringBootSales.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.it.SpringBootSales.Service.ProductService;
import com.example.it.SpringBootSales.model.Product;

@RestController
@EnableWebMvc
@RequestMapping("/product")
public class ProductRestController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping(produces="application/json")
	public Collection<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@GetMapping(value="{id}",produces="application/json")
	public Product getProduct(@PathVariable int id){
		return productService.getProduct(id);
	}
	
	@PostMapping(consumes="application/json",produces="application/json")
	public Product saveProduct(@RequestBody Product product){
		return productService.saveProduct(product);
	}
	
	@PostMapping(value="{id}",consumes="application/json",produces="application/json")
	public Product updateProduct(@PathVariable int id,@RequestBody Product product){
		if(productService.checkProductById(id)){
			product.setPno(id);
			return productService.updateProduct(product);
		}
		return null;
	}
}
