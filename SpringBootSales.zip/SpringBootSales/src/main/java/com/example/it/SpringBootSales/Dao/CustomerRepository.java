package com.example.it.SpringBootSales.Dao;

import org.springframework.stereotype.Repository;
import com.example.it.SpringBootSales.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
	Customer findByCustid(String id);
}
